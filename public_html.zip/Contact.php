<?php
include "Header.php";

	echo "
	For job applications, general help, questions, or ban appeals, please email <a href='mailto:help@social-paradise.net'><b>help@social-paradise.net</b></a>
	<br />
	";

include "Footer.php";
?>