<div id='txtHint'>
<?php
$time = time();
echo "<font style='font-size:18px;'>";
echo date("g:i A T",$time);
echo "</font>";

?>
</div> 
