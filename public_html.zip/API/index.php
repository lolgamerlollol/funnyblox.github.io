<?php
include "../403.shtml";
die;
?>