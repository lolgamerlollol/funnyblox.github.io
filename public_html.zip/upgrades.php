<?php
	include "Header.php";
header("Location: http://social-paradise.net/Memberships/UpgradeAccount.php");
?>
?>