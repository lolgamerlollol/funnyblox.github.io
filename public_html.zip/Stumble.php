<?php include "Header.php"
?>


<html>
<b>
Woah there, you've stumbled upon this page too fast. Come back later when it's been finished!
<br />
-Social Paradise Administration
</b>
</html>

<?php include "Footer.php"
?>