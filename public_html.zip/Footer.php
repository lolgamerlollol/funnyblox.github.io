<?
mysql_close($connection);
mysql_close($connection1);
?>
</div>
</div>
<br />
<center>
<style>
#footer3 a {
color:#999;
}
#footer3 a:hover {
text-decoration:underline;
}
</style>
<div style='width:1000px;'>
<div align='left' style='color:#999;text-shadow:0px 0px 1px white;' id='footer3'>
<b>
Copyright &copy; 2012 Social-Paradise - <a href='http://www.social-paradise.net/siterules.php'>Terms Of Service</a> - <a href='../Contact.php'>Contact Us</a>
</b>
</div>
</div>
<br />