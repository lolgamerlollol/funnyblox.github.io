<?php
include "Header.php";

	echo "<center><font style='font-size:25px;'>Thank You</font><br />Thank you, <b>$User</b>, your premium membership is now active.";

include "Footer.php";