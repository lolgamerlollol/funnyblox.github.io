<?php
include "Permissions.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" xmlns:fb="http://www.facebook.com/2008/fbml">
	<head>
		<title>Administration | Social-Paradise</title>
		<link rel="stylesheet" href="http://social-paradise.net/Base/Style/Main.css">
	</head>
		<body>
			<center>
				<img src='http://www.social-paradise.net/Imagess/SPNewLogo.png'>
				<br />
				<br />
			<style>
				#header {
				background:#454545;
				height:35px;
				width:1200px;
				padding-left:16px;
				padding-right:16px;
				}
				
				#header a {
				color:white;
				font-weight:bold;
				color:white;
				font-size:12px;
				}
				
				#header td {
				padding-left:10px;
				padding-right:10px;
				padding-top:10px;
				}
				
				#container {
				width:1200px;
				background:white;
				border:1px solid gray;
				border-top:0;
				padding:15px;
				}
			</style>
			<div id='header'>
				<table cellspacing='0' cellpadding='0'>
					<tr>
						<td>
							<a href='../Administration/'>Home</a>
						</td>
						<td>
							<a href='../Administration/Users.php'>Manage Users</a>
						</td>
					</tr>
				</table>
			</div>
			<div id='container'><div align='left'>